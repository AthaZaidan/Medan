<?php $__env->startSection('title', 'Dashboard Utama'); ?>
<?php $__env->startSection('heading', 'Dashboard Utama'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">

    
    <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        
        <div class="admin-card p-4">
            <div class="text-xs font-semibold text-slate-500">Rata-rata QPI Kota</div>
            <div class="text-3xl font-bold text-slate-900 mt-2 tabular-nums">
                <?php echo e($statistik['rata_rata_qpi'] !== null ? number_format($statistik['rata_rata_qpi'], 1) : '—'); ?>

            </div>
            <div class="text-[11px] text-slate-400 mt-1">21 Kecamatan</div>
        </div>

        
        <div class="admin-card p-4">
            <div class="text-xs font-semibold text-slate-500">Sangat Baik</div>
            <div class="text-3xl font-bold text-emerald-700 mt-2 tabular-nums">
                <?php echo e($statistik['jumlah_sangat_baik']); ?>

            </div>
            <div class="text-[11px] text-slate-400 mt-1">QPI ≥ 85.0</div>
        </div>

        
        <div class="admin-card p-4">
            <div class="text-xs font-semibold text-slate-500">Floor Aktif</div>
            <div class="text-3xl font-bold <?php echo e($statistik['jumlah_floor'] > 0 ? 'text-amber-700' : 'text-slate-900'); ?> mt-2 tabular-nums">
                <?php echo e($statistik['jumlah_floor']); ?>

            </div>
            <div class="text-[11px] text-slate-400 mt-1">Dimensi &lt; 50.0</div>
        </div>

        
        <div class="admin-card p-4">
            <div class="text-xs font-semibold text-slate-500">Kritis</div>
            <div class="text-3xl font-bold <?php echo e($statistik['jumlah_kritis'] > 0 ? 'text-red-700' : 'text-slate-900'); ?> mt-2 tabular-nums">
                <?php echo e($statistik['jumlah_kritis']); ?>

            </div>
            <div class="text-[11px] text-slate-400 mt-1">Termasuk Floor</div>
        </div>
    </div>

    
    <?php if($statistik['kecamatan_terendah']): ?>
    <div class="p-3 bg-red-50 border border-red-200 rounded text-xs text-red-900 font-medium">
        Kecamatan dengan skor terendah: <strong class="font-bold underline"><?php echo e($statistik['kecamatan_terendah']); ?></strong> (Skor: <?php echo e(number_format($statistik['qpi_terendah'], 1)); ?>).
    </div>
    <?php endif; ?>

    
    <div class="admin-card overflow-hidden">
        <div class="admin-card-header flex items-center justify-between">
            <h2 class="text-xs font-bold text-slate-900 uppercase tracking-wider">Peringkat 21 Kecamatan</h2>
            <span class="text-[11px] text-slate-500">QPI Inti</span>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-xs">
                <thead>
                    <tr class="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase tracking-wider">
                        <th class="px-4 py-2.5 text-center w-12">No</th>
                        <th class="px-4 py-2.5 text-left">Kecamatan</th>
                        <th class="px-4 py-2.5 text-center">QPI Inti</th>
                        <th class="px-4 py-2.5 text-center">Kategori</th>
                        <?php $__currentLoopData = ['D1','D2','D3','D4','D5','D6','D7']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="px-2.5 py-2.5 text-center"><?php echo e($d); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th class="px-4 py-2.5 text-center">Floor</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 bg-white">
                    <?php $__currentLoopData = $peringkat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-slate-50/80 transition-colors">
                        <td class="px-4 py-2.5 text-center font-bold text-slate-400 tabular-nums">
                            <?php echo e($row['rank'] ?? '—'); ?>

                        </td>
                        <td class="px-4 py-2.5 font-bold text-slate-900">
                            <a href="<?php echo e(route('kecamatan.detail', $row['kecamatan'])); ?>" class="text-blue-900 hover:underline">
                                <?php echo e($row['kecamatan']->nama); ?>

                            </a>
                        </td>
                        <td class="px-4 py-2.5 text-center tabular-nums">
                            <?php if($row['qpi_inti'] !== null): ?>
                                <span class="font-bold text-sm <?php echo $__env->make('components._score-color-class', ['score' => $row['qpi_inti']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>">
                                    <?php echo e(number_format($row['qpi_inti'], 1)); ?>

                                </span>
                            <?php else: ?>
                                <span class="text-slate-300">—</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-2.5 text-center">
                            <?php if($row['kategori']): ?>
                                <?php echo $__env->make('components._kategori-badge', ['kategori' => $row['kategori']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php else: ?>
                                <span class="text-slate-300 italic">—</span>
                            <?php endif; ?>
                        </td>
                        <?php $__currentLoopData = ['D1','D2','D3','D4','D5','D6','D7']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="px-2.5 py-2.5 text-center tabular-nums font-semibold">
                                <?php if($row['dimensi'][$d] !== null): ?>
                                    <span class="<?php echo $__env->make('components._score-color-class', ['score' => $row['dimensi'][$d]], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>">
                                        <?php echo e(number_format($row['dimensi'][$d], 1)); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="text-slate-300">—</span>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td class="px-4 py-2.5 text-center">
                            <?php if($row['floor_aktif'] === true): ?>
                                <span class="badge badge-perlu-perbaikan">AKTIF</span>
                            <?php else: ?>
                                <span class="text-slate-300">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="grid grid-cols-1 xl:grid-cols-2 gap-6">
        
        <div class="admin-card overflow-hidden">
            <div class="admin-card-header">
                <h3 class="text-xs font-bold text-slate-900 uppercase tracking-wider">10 Indikator Terlemah (Rata-rata Kota)</h3>
            </div>
            <div class="p-4 space-y-3 bg-white">
                <?php $__empty_1 = true; $__currentLoopData = $topIndikator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="space-y-1">
                        <div class="flex items-center justify-between text-xs">
                            <div class="flex items-center gap-2 min-w-0 pr-2">
                                <span class="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700 font-mono font-bold text-[10px] border border-slate-200">
                                    <?php echo e($item['indikator']->kode); ?>

                                </span>
                                <span class="text-slate-800 font-medium truncate"><?php echo e($item['indikator']->pernyataan); ?></span>
                            </div>
                            <span class="font-bold flex-shrink-0 text-xs tabular-nums <?php echo $__env->make('components._score-color-class', ['score' => $item['rata_rata_kota'] ?? 0], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>">
                                <?php echo e($item['rata_rata_kota'] !== null ? number_format($item['rata_rata_kota'], 1) : '—'); ?>

                            </span>
                        </div>
                        <div class="h-1.5 bg-slate-100 rounded overflow-hidden">
                            <div class="h-full transition-all duration-300 <?php echo $__env->make('components._score-bg-class', ['score' => $item['rata_rata_kota'] ?? 0], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>"
                                 style="width: <?php echo e($item['rata_rata_kota'] ?? 0); ?>%"></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-xs text-slate-400 text-center py-6">Belum Ada Data</p>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="admin-card overflow-hidden">
            <div class="admin-card-header">
                <h3 class="text-xs font-bold text-slate-900 uppercase tracking-wider">5 Sub-Variabel Terlemah (Rata-rata Kota)</h3>
            </div>
            <div class="p-4 space-y-3 bg-white">
                <?php $__empty_1 = true; $__currentLoopData = $topSubVariabel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-3 rounded bg-slate-50 border border-slate-200">
                        <div class="flex items-start justify-between">
                            <div class="min-w-0 flex-1">
                                <p class="text-xs text-slate-900 font-bold truncate"><?php echo e($item['sub_variabel']->nama); ?></p>
                                <p class="text-[11px] text-slate-500 mt-0.5"><?php echo e($item['sub_variabel']->kuesioner->nama); ?></p>
                            </div>
                            <span class="text-base font-bold flex-shrink-0 ml-3 tabular-nums <?php echo $__env->make('components._score-color-class', ['score' => $item['rata_rata_kota'] ?? 0], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>">
                                <?php echo e($item['rata_rata_kota'] !== null ? number_format($item['rata_rata_kota'], 1) : '—'); ?>

                            </span>
                        </div>
                        <div class="h-1.5 bg-slate-200 rounded overflow-hidden mt-2">
                            <div class="h-full transition-all duration-300 <?php echo $__env->make('components._score-bg-class', ['score' => $item['rata_rata_kota'] ?? 0], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>"
                                 style="width: <?php echo e($item['rata_rata_kota'] ?? 0); ?>%"></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-xs text-slate-400 text-center py-6">Belum Ada Data</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/muftifardan/Documents/Medan/resources/views/dashboard/index.blade.php ENDPATH**/ ?>