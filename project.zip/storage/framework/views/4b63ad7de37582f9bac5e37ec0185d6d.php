<?php $__env->startSection('title', 'Form Checklist — ' . $kuesioner->kode); ?>
<?php $__env->startSection('heading', 'Form Evaluasi Kuesioner ' . $kuesioner->kode . ' — ' . $kecamatan->nama); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">

    
    <a href="<?php echo e(route('input.progress')); ?>" class="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-blue-900 transition-colors">
        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5"/></svg>
        Kembali ke Progress
    </a>

    <div class="admin-card p-4 flex items-center justify-between">
        <div>
            <span class="text-[10px] font-bold text-slate-400 uppercase">KUESIONER <?php echo e($kuesioner->kode); ?></span>
            <h1 class="text-base font-bold text-slate-900"><?php echo e($kuesioner->nama); ?></h1>
            <p class="text-xs text-slate-500 mt-0.5">Kecamatan: <strong class="font-bold text-slate-800"><?php echo e($kecamatan->nama); ?></strong></p>
        </div>
        <span class="text-xs font-semibold text-slate-500 bg-slate-100 px-3 py-1.5 rounded border border-slate-200">
            Skala Guttman (Ya / Tidak)
        </span>
    </div>

    <form action="<?php echo e(route('input.store')); ?>" method="POST" class="space-y-6">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="kecamatan_id" value="<?php echo e($kecamatan->id); ?>">
        <input type="hidden" name="kuesioner_id" value="<?php echo e($kuesioner->id); ?>">

        <?php $__currentLoopData = $subVariabels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="admin-card overflow-hidden">
                <div class="admin-card-header">
                    <h3 class="text-xs font-bold text-slate-900 uppercase tracking-wider"><?php echo e($sv->nama); ?></h3>
                    <p class="text-[11px] text-slate-500 mt-0.5 font-medium">Bobot Subtotal Instrumen: <?php echo e($sv->bobot_subtotal); ?>%</p>
                </div>

                <?php $__currentLoopData = $sv->indikators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ind): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border-b border-slate-200 last:border-0" x-data="{ collapsed: false }">
                        <div class="px-5 py-3 bg-slate-50 flex items-center gap-3 cursor-pointer hover:bg-slate-100 transition-colors" @click="collapsed = !collapsed">
                            <span class="text-xs font-mono font-bold text-slate-700 w-8 px-1.5 py-0.5 bg-slate-200 rounded text-center"><?php echo e($ind->kode); ?></span>
                            <span class="text-xs text-slate-900 font-bold flex-1"><?php echo e($ind->pernyataan); ?></span>
                            <span class="text-[11px] text-slate-500 font-medium">Bobot: <?php echo e($ind->bobot_asli); ?>%</span>
                            <svg class="w-4 h-4 text-slate-400 transition-transform" :class="collapsed && 'rotate-180'" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="m19.5 8.25-7.5 7.5-7.5-7.5"/></svg>
                        </div>

                        <div x-show="!collapsed" x-transition class="px-5 py-2.5 bg-white space-y-2">
                            <?php $__currentLoopData = $ind->subItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $si): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $currentVal = $existingAnswers[$si->id] ?? null; ?>
                                <div class="flex items-center gap-4 py-1.5 border-b border-slate-100 last:border-0">
                                    <span class="text-xs font-bold text-slate-400 font-mono w-4"><?php echo e($si->kode); ?></span>
                                    <span class="text-xs text-slate-800 font-medium flex-1 leading-relaxed"><?php echo e($si->teks); ?></span>
                                    <div class="flex items-center gap-3 flex-shrink-0">
                                        <label class="flex items-center gap-1.5 cursor-pointer px-2.5 py-1 rounded bg-slate-50 border border-slate-300 hover:bg-emerald-50 hover:border-emerald-300 transition-colors">
                                            <input type="radio" name="jawaban[<?php echo e($si->id); ?>]" value="1"
                                                   <?php echo e($currentVal === true || $currentVal === 1 ? 'checked' : ''); ?>

                                                   class="w-3.5 h-3.5 text-emerald-600 border-slate-300 focus:ring-emerald-500">
                                            <span class="text-xs font-bold text-slate-800">Ya</span>
                                        </label>
                                        <label class="flex items-center gap-1.5 cursor-pointer px-2.5 py-1 rounded bg-slate-50 border border-slate-300 hover:bg-red-50 hover:border-red-300 transition-colors">
                                            <input type="radio" name="jawaban[<?php echo e($si->id); ?>]" value="0"
                                                   <?php echo e($currentVal === false || $currentVal === 0 ? 'checked' : ''); ?>

                                                   class="w-3.5 h-3.5 text-red-600 border-slate-300 focus:ring-red-500">
                                            <span class="text-xs font-bold text-slate-800">Tidak</span>
                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <div class="flex justify-end">
            <button type="submit"
                    class="px-6 py-2.5 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded shadow-xs transition-colors text-xs">
                Simpan Jawaban
            </button>
        </div>
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/muftifardan/Documents/Medan/resources/views/input/show.blade.php ENDPATH**/ ?>