<?php $__env->startSection('title', 'Progress Input'); ?>
<?php $__env->startSection('heading', 'Progress Input Data'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">

    <div class="admin-card p-4">
        <h2 class="text-xs font-bold text-slate-900 uppercase tracking-wider">Matriks Progress Kelengkapan Data</h2>
        <p class="text-xs text-slate-500 mt-0.5">Klik sel untuk mengisi atau mengubah data kuesioner kecamatan.</p>
    </div>

    <div class="admin-card overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-xs">
                <thead>
                    <tr class="bg-slate-50 border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider">
                        <th class="px-4 py-3 text-left sticky left-0 bg-slate-50 z-10 border-r border-slate-200">Kecamatan</th>
                        <?php $__currentLoopData = $kuesioners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="px-3 py-3 text-center">
                                <div class="text-slate-900 font-bold">Modul <?php echo e($k->kode); ?></div>
                                <div class="text-[10px] normal-case text-slate-500 font-normal mt-0.5"><?php echo e(Str::limit($k->nama, 16)); ?></div>
                            </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 bg-white">
                    <?php $__currentLoopData = $progressData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-slate-50/80 transition-colors">
                            <td class="px-4 py-2.5 font-bold text-slate-900 sticky left-0 bg-white z-10 text-xs border-r border-slate-200">
                                <?php echo e($row['kecamatan']->nama); ?>

                            </td>
                            <?php $__currentLoopData = $kuesioners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $prog = $row['progress'][$k->kode] ?? ['percent' => 0, 'filled' => 0, 'total' => 0];
                                    $pct = $prog['percent'];
                                    $bgClass = $pct >= 100 ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : ($pct > 0 ? 'bg-amber-50 text-amber-800 border-amber-200' : 'bg-slate-50 text-slate-400 border-slate-200');
                                ?>
                                <td class="px-1.5 py-1.5 text-center">
                                    <a href="<?php echo e(route('input.show', [$k, $row['kecamatan']])); ?>"
                                       class="block rounded p-1.5 border <?php echo e($bgClass); ?> hover:border-slate-400 transition-colors">
                                        <div class="font-bold tabular-nums"><?php echo e(number_format($pct, 0)); ?>%</div>
                                        <div class="text-[9px] opacity-70 font-mono mt-0.5"><?php echo e($prog['filled']); ?>/<?php echo e($prog['total']); ?></div>
                                    </a>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/muftifardan/Documents/Medan/resources/views/input/progress.blade.php ENDPATH**/ ?>